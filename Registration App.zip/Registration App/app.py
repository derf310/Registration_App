import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

CSV_FILE = Path(__file__).resolve().parent / "data" / "user.csv" 
FIELDNAMES = ["id", "fullname", "email", "phone", "notes", "registeredAt"]
TZ_GMT7 = timezone(timedelta(hours=7))

#mengambil waktu/tanggal saat ini dan mengubahnya menjadi bentuk teks (string) yang sudah disesuaikan dengan zona waktu GMT+7
def now_gmt7_str() -> str:
    return datetime.now(TZ_GMT7).strftime("%d/%m/%Y %H:%M GMT+7")

#digunakan untuk memastikan bahwa sebuah file CSV memiliki baris judul (header) di bagian paling atas sebelum data mulai ditulis.
def ensure_csv_header() -> None:
    CSV_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not CSV_FILE.exists() or CSV_FILE.stat().st_size == 0:
        with CSV_FILE.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()

#digunakan untuk memuat atau mengambil data dari suatu sumber (seperti file JSON, database, atau file CSV) dan mengembalikannya dalam bentuk list yang berisi dictionary
def load_data() -> list[dict]:
    ensure_csv_header()
    try:
        with CSV_FILE.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = []
            for row in reader:
                if row and str(row.get("id", "")).strip():
                    rows.append({
                        "id": str(row.get("id", "")).strip(),
                        "fullname": str(row.get("fullname", "")).strip(),
                        "email": str(row.get("email", "")).strip(),
                        "phone": str(row.get("phone", "")).strip() or "-",
                        "notes": str(row.get("notes", "")).strip() or "-",
                        "registeredAt": str(row.get("registeredAt", "")).strip(),
                    })
            return rows
    except OSError:
        return []

#digunakan untuk menyimpan data (dalam format list yang berisi dictionary) ke dalam media penyimpanan, seperti file (misalnya JSON atau CSV) atau database.
#None adalah sebuah nilai khusus yang merepresentasikan "tidak ada nilai", kosong, atau null di bahasa pemrograman lain.
def save_data(items: list[dict]) -> None:
    ensure_csv_header()
    with CSV_FILE.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        for item in items:
            writer.writerow({field: item.get(field, "") for field in FIELDNAMES})

#digunakan untuk menghasilkan ID unik berikutnya untuk pengguna baru berdasarkan daftar data yang sudah ada (items).
def next_user_id(items: list[dict]) -> str:
    numeric_ids = [
        int(item["id"])
        for item in items
        if str(item.get("id", "")).strip().isdigit()
    ]
    return str(max(numeric_ids, default=0) + 1)


# --- Page Routes ---
#Dekorator yang memberi tahu Flask bahwa fungsi di bawahnya akan merespons ketika pengguna mengakses halaman utama (root URL).
@app.route("/")
#Fungsi Python yang akan dieksekusi saat halaman utama dikunjungi.
def home():
    #Perintah untuk merender dan menampilkan file template HTML (index.html) ke layar pengguna.
    return render_template("index.html")

#digunakan untuk membuat rute URL dinamis di Flask yang menerima parameter variabel (user_id).
@app.route("/userdetails/<user_id>")
def user_details(user_id: str):
    items = load_data()
    if not any(item.get("id") == user_id for item in items):
        return render_template("error.html"), 404
    return render_template("userdetails.html")

#potongan kode di atas digunakan untuk membuat rute halaman error (kesalahan) pada aplikasi Flask.
@app.route("/error")
def error_page():
    return render_template("error.html")


# --- CRUD API Routes ---
#Menentukan jalur URL /api/registrations yang hanya bisa diakses menggunakan metode HTTP GET
@app.route("/api/registrations", methods=["GET"])
def get_registrations():
    #Memuat atau membaca seluruh data yang tersimpan (menggunakan fungsi load_data yang dibahas sebelumnya).
    items = load_data()
    #Mengirimkan data ke klien dalam bentuk JSON
    return jsonify({"registrations": items, "total": len(items)}), 200


@app.route("/api/registrations", methods=["POST"])
def create_registration():
    #Mengambil data JSON yang dikirim oleh klien, lalu merapikan kolom fullname, email, phone, dan notes
    payload = request.get_json(silent=True) or {}
    fullname = str(payload.get("fullname", "")).strip()
    email = str(payload.get("email", "")).strip()
    phone = str(payload.get("phone", "")).strip() or "-"
    notes = str(payload.get("notes", "")).strip() or "-"

    #Validasi: Mengecek apakah nama lengkap (fullname) dan email (email) sudah diisi. Jika salah satu atau keduanya kosong, server akan merespons dengan pesan error dan status kode 400 (Bad Request).
    if not fullname or not email:
        return jsonify({"error": "Full name and email are required."}), 400

    #Mengemas data ke dalam sebuah dictionary (new_item) lengkap dengan ID unik (next_user_id) dan stempel waktu pendaftaran (now_gmt7_str).
    items = load_data()
    new_item = {
        "id": next_user_id(items),
        "fullname": fullname,
        "email": email,
        "phone": phone,
        "notes": notes,
        "registeredAt": now_gmt7_str(),
    }

    #Memasukkan data baru tersebut ke dalam daftar data, lalu menyimpannya secara permanen menggunakan fungsi save_data().
    items.append(new_item)
    save_data(items)

    #Mengembalikan data pendaftaran yang baru saja dibuat beserta total data saat ini dengan status kode HTTP 201 (Created), yang menandakan bahwa data berhasil dibuat di server.
    return jsonify({"registration": new_item, "total": len(items)}), 201


#Menentukan jalur URL dinamis dengan parameter user_id yang hanya bisa diakses menggunakan metode HTTP GET.
@app.route("/api/registrations/<user_id>", methods=["GET"])
def get_registration_detail(user_id: str):
    #Memuat seluruh data dengan load_data(), lalu mencari item di dalam list yang memiliki id sama dengan user_id menggunakan fungsi next(). Jika tidak ditemukan, variabel user akan bernilai None.
    items = load_data()
    user = next((item for item in items if item.get("id") == user_id), None)
    #Jika data pengguna tidak ditemukan (user bernilai None), server akan merespons dengan pesan error dan status kode 404
    if not user:
        return jsonify({"error": "Registration not found."}), 404

    #Jika data ditemukan, server akan mengembalikan data detail pendaftaran tersebut beserta jumlah total data dengan status kode 200
    return jsonify({"registration": user, "total": len(items)}), 200


#Menentukan jalur URL dinamis untuk menerima permintaan ubah data menggunakan metode HTTP PUT.
@app.route("/api/registrations/<user_id>", methods=["PUT"])
#Mengambil data JSON terbaru dari klien lalu merapikan kolom fullname, email, phone, dan notes.
def update_registration(user_id: str):
    payload = request.get_json(silent=True) or {}
    fullname = str(payload.get("fullname", "")).strip()
    email = str(payload.get("email", "")).strip()
    phone = str(payload.get("phone", "")).strip() or "-"
    notes = str(payload.get("notes", "")).strip() or "-"

    #Memastikan bahwa nama lengkap dan email tidak kosong. Jika kosong, server merespons dengan status 400
    if not fullname or not email:
        return jsonify({"error": "Full name and email cannot be empty."}), 400

    #Fungsi melakukan pencarian dalam daftar data (items) menggunakan perulangan (enumerate).
    items = load_data()
    for idx, item in enumerate(items):
        if item.get("id") == user_id:
            updated = {
                "id": item["id"],
                "fullname": fullname,
                "email": email,
                "phone": phone,
                "notes": notes,
                "registeredAt": item.get("registeredAt") or now_gmt7_str(),
            }
            #Jika data dengan id yang cocok ditemukan, data lama akan ditimpa dengan data baru (updated), sementara tanggal pendaftaran awal (registeredAt) tetap dipertahankan.
            items[idx] = updated
            save_data(items)
            #Data langsung disimpan secara permanen lewat save_data() dan mengembalikan respons sukses dengan status 200
            return jsonify({"registration": updated, "total": len(items)}), 200

    #Jika setelah pencarian selesai ID tidak ditemukan di dalam sistem, server akan mengembalikan pesan error dengan status 404
    return jsonify({"error": "Registration not found."}), 404


#Menentukan jalur URL dinamis untuk menerima permintaan penghapusan data menggunakan metode HTTP DELETE.
@app.route("/api/registrations/<user_id>", methods=["DELETE"])
def delete_registration(user_id: str):
    #Memuat seluruh data dengan load_data(), lalu membuat daftar baru yang berisi semua data kecuali data yang memiliki id sama dengan user_id yang ingin dihapus.
    items = load_data()
    new_items = [item for item in items if item.get("id") != user_id]
    if len(new_items) == len(items):
        #Membandingkan jumlah data sebelum dan sesudah disaring. Jika jumlahnya sama (artinya ID tidak ditemukan di dalam sistem), server akan mengembalikan pesan error dengan status 404
        return jsonify({"error": "Registration not found."}), 404

    #Jika data berhasil disaring (dihapus), daftar baru tersebut disimpan secara permanen lewat save_data(), lalu server mengembalikan respons sukses berupa keterangan { "deleted": True } dan total sisa data dengan status 200 (OK).
    save_data(new_items)
    return jsonify({"deleted": True, "total": len(new_items)}), 200


#Sebuah pengecekan standar di Python untuk memastikan bahwa file skrip ini dijalankan secara langsung
if __name__ == "__main__":
    app.run(debug=True)