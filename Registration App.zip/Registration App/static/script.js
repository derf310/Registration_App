// Fungsi utilitas untuk mengubah karakter khusus HTML menjadi HTML entity agar teks dari input pengguna aman ditampilkan di dalam innerHTML.
function escapeHTML(str = "") {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

// Mengekstrak parameter ID pengguna dari path URL halaman saat ini (misalnya /userdetails/1 menghasilkan "1").
function getUserIdFromPath() {
  // window.location.pathname bernilai "/userdetails/1". split("/") menghasilkan ["", "userdetails", "1"].
  // filter(Boolean) membuang string kosong sehingga parts menjadi ["userdetails", "1"].
  const parts = window.location.pathname.split("/").filter(Boolean);
  if (parts[0] === "userdetails") {
    if (parts[1]) {
      return decodeURIComponent(parts[1]);
    }
  }
  return null;
}

// INDEX PAGE: GET list (Read) + POST (create) + PUT (update) + DELETE
function initIndexPage() {
  // Mencari elemen pertama (querySelector) di dokumen HTML yang cocok dengan selektor CSS (class).
  const formContainer = document.querySelector(".registration_form");
  const registrantsBox = document.querySelector(".registrants");
  const statValue = document.querySelector(".statistic_value");

  // Jika elemen .registration_form atau .registrants tidak ada di halaman, initIndexPage() langsung berhenti (return) tanpa error.
  if (!formContainer) {
    return;
  }
  if (!registrantsBox) {
    return;
  }

  // Mencari elemen input berdasarkan ID di dokumen HTML.
  const fullnameInput = document.getElementById("fullname");
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phonenumber");
  const notesInput = document.getElementById("notes");

  // Mencari tombol submit dan judul form hanya di dalam formContainer.
  const submitBtn = formContainer.querySelector(".submit-btn");
  const formTitle = formContainer.querySelector(".registration_title");

  // Mencari elemen pembungkus (.form_group) terdekat di atas notesInput.
  let notesGroup = null;
  if (notesInput) {
    const foundGroup = notesInput.closest(".form_group");
    if (foundGroup) {
      notesGroup = foundGroup;
    }
  }

  // Membuat elemen notifikasi baru bertipe <div> (belum tampil sampai dimasukkan ke DOM).
  const updateNotice = document.createElement("div");
  updateNotice.className = "update_notification";

  // Menempatkan updateNotice tepat setelah notesGroup (jika ada nextSibling), atau tepat sebelum submitBtn sebagai posisi cadangan.
  if (submitBtn) {
    if (notesGroup) {
      if (notesGroup.nextSibling) {
        formContainer.insertBefore(updateNotice, notesGroup.nextSibling);
      } else {
        formContainer.insertBefore(updateNotice, submitBtn);
      }
    } else {
      formContainer.insertBefore(updateNotice, submitBtn);
    }
  }

  // Menyimpan ID timer notifikasi aktif agar bisa di-reset bila notifikasi dipicu ulang sebelum 3,5 detik.
  let noticeTimeout = null;

  // Menghapus class "is-visible" untuk menyembunyikan notifikasi.
  function hideUpdateNotice() {
    updateNotice.classList.remove("is-visible");
  }

  // Menampilkan pesan notifikasi lalu menjadwalkan penyembunyian otomatis setelah 3500 ms (3,5 detik).
  function showUpdateNotice(message) {
    updateNotice.textContent = message;
    updateNotice.classList.add("is-visible");

    if (noticeTimeout !== null) {
      clearTimeout(noticeTimeout);
      noticeTimeout = null;
    }

    noticeTimeout = setTimeout(hideUpdateNotice, 3500);
  }

  // Menyimpan teks awal judul dan tombol agar bisa dikembalikan saat keluar dari mode edit.
  let defaultTitleText = "Register";
  if (formTitle && formTitle.textContent) {
    defaultTitleText = formTitle.textContent;
  }

  let defaultBtnText = "Register";
  if (submitBtn && submitBtn.textContent) {
    defaultBtnText = submitBtn.textContent;
  }

  // Membaca query parameter ?edit=<id> dari URL (misalnya /?edit=2).
  const params = new URLSearchParams(window.location.search);
  let editingId = params.get("edit");

  // Mengubah tampilan judul form dan label tombol submit antara mode tambah ("Register") dan mode edit ("Update").
  function setEditModeUI(active) {
    if (formTitle) {
      if (active) {
        formTitle.textContent = "Edit Registration";
      } else {
        formTitle.textContent = defaultTitleText;
      }
    }

    if (submitBtn) {
      if (active) {
        submitBtn.textContent = "Update";
      } else {
        submitBtn.textContent = defaultBtnText;
      }
    }
  }

  // Mengosongkan semua input form, mereset status editingId, mengembalikan UI ke mode tambah, dan membersihkan query string di URL.
  function clearForm() {
    if (fullnameInput) fullnameInput.value = "";
    if (emailInput) emailInput.value = "";
    if (phoneInput) phoneInput.value = "";
    if (notesInput) notesInput.value = "";
    editingId = null;
    setEditModeUI(false);
    if (window.location.search) {
      window.history.replaceState({}, "", "/");
    }
  }

  // Mengambil data pendaftar berdasarkan userId dari backend lalu mengisi form untuk diedit.
  async function prefillEditForm(userId) {
    try {
      const encodedId = encodeURIComponent(userId);
      const res = await fetch(`/api/registrations/${encodedId}`);

      // Jika data tidak ditemukan / gagal diambil, bersihkan form dan hentikan proses.
      if (!res.ok) {
        clearForm();
        return;
      }

      const data = await res.json();
      const user = data.registration;

      if (!user) {
        clearForm();
        return;
      }

      if (fullnameInput) {
        let fullnameValue = "";
        if (user.fullname) {
          fullnameValue = user.fullname;
        }
        fullnameInput.value = fullnameValue;
      }

      if (emailInput) {
        let emailValue = "";
        if (user.email) {
          emailValue = user.email;
        }
        emailInput.value = emailValue;
      }

      // Jika nilai phone atau notes di CSV adalah "-", ubah menjadi string kosong agar mudah diedit ulang.
      if (phoneInput) {
        let phoneValue = "";
        if (user.phone && user.phone !== "-") {
          phoneValue = user.phone;
        }
        phoneInput.value = phoneValue;
      }

      if (notesInput) {
        let notesValue = "";
        if (user.notes && user.notes !== "-") {
          notesValue = user.notes;
        }
        notesInput.value = notesValue;
      }

      // Tandai bahwa form sedang mengedit data dengan ID milik user ini.
      editingId = user.id;
      setEditModeUI(true);

      // Arahkan fokus kursor ke input nama lengkap.
      if (fullnameInput) {
        fullnameInput.focus();
      }
    } catch (err) {
      console.error("Failed to prefill edit form:", err);
      clearForm();
    }
  }

  // Menghapus data pendaftar tertentu lewat API DELETE dari tombol Delete di daftar pendaftar.
  async function handleDeleteFromList(userId, deleteBtn) {
    const confirmed = confirm("Are you sure you want to remove this registration?");

    if (!confirmed) {
      return;
    }

    // Nonaktifkan tombol sementara agar tidak terjadi klik ganda saat proses hapus berlangsung.
    deleteBtn.disabled = true;

    try {
      const encodedId = encodeURIComponent(userId);
      const res = await fetch(`/api/registrations/${encodedId}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        alert("Failed to delete registration.");
        deleteBtn.disabled = false;
        return;
      }

      // Jika data yang dihapus sedang aktif diedit di form, reset form ke mode tambah.
      if (editingId === userId) {
        clearForm();
      }

      // Muat ulang daftar pendaftar agar tampilan selalu sinkron dengan data terbaru.
      await fetchRegistrations();
    } catch (err) {
      console.error(err);
      alert("Network error while deleting registration.");
      deleteBtn.disabled = false;
    }
  }

  // Merender angka statistik total pendaftar dan daftar kartu pendaftar ke dalam registrantsBox.
  function renderRegistrants(list, total) {
    if (statValue) {
      let countValue = list.length;
      if (total !== undefined && total !== null) {
        countValue = total;
      }
      statValue.textContent = String(countValue);
    }

    // Hapus item pendaftar atau pesan kosong sebelumnya agar tidak duplikat saat render ulang.
    const oldNodes = registrantsBox.querySelectorAll(
      ".registrant-item, .registrations_alert"
    );
    for (const el of oldNodes) {
      el.remove();
    }

    // Jika belum ada pendaftar sama sekali, tampilkan pesan kosong.
    if (!list.length) {
      const alertP = document.createElement("p");
      alertP.className = "registrations_alert";
      alertP.textContent = "No one has registered yet. Be the first.";
      registrantsBox.appendChild(alertP);
      return;
    }

    // Buat elemen baris/kartu untuk setiap pendaftar.
    for (const person of list) {
      const item = document.createElement("div");
      item.className = "registrant-item";

      const info = document.createElement("div");
      info.className = "registrant-info";

      const nameEl = document.createElement("strong");
      nameEl.className = "registrant-name";
      nameEl.textContent = person.fullname || "";

      const emailEl = document.createElement("div");
      emailEl.className = "registrant-email";
      emailEl.textContent = person.email || "";

      info.appendChild(nameEl);
      info.appendChild(emailEl);

      const actions = document.createElement("div");
      actions.className = "registrant-actions";

      const encodedId = encodeURIComponent(person.id);

      // Link menuju halaman detail pendaftar (/userdetails/<id>).
      const viewLink = document.createElement("a");
      viewLink.href = `/userdetails/${encodedId}`;
      viewLink.textContent = "View";
      viewLink.className = "action-btn action-view";

      // Tombol Edit yang mengarahkan ke /?edit=<id> untuk memuat data ke form.
      const editBtn = document.createElement("button");
      editBtn.type = "button";
      editBtn.textContent = "Edit";
      editBtn.className = "action-btn action-edit";
      editBtn.addEventListener("click", function () {
        window.location.href = `/?edit=${encodedId}`;
      });

      // Tombol Delete untuk menghapus data pendaftar ini.
      const deleteBtn = document.createElement("button");
      deleteBtn.type = "button";
      deleteBtn.textContent = "Delete";
      deleteBtn.className = "action-btn action-delete";
      deleteBtn.addEventListener("click", function () {
        handleDeleteFromList(person.id, deleteBtn);
      });

      actions.appendChild(viewLink);
      actions.appendChild(editBtn);
      actions.appendChild(deleteBtn);

      item.appendChild(info);
      item.appendChild(actions);
      registrantsBox.appendChild(item);
    }
  }

  // Mengambil seluruh data pendaftar dari backend (/api/registrations) lalu merendernya ke UI.
  async function fetchRegistrations() {
    try {
      const res = await fetch("/api/registrations");

      if (!res.ok) {
        throw new Error("Failed to fetch registrations");
      }

      const data = await res.json();

      let registrationsList = [];
      if (data && Array.isArray(data.registrations)) {
        registrationsList = data.registrations;
      }

      let totalCount = 0;
      if (data && data.total !== undefined && data.total !== null) {
        totalCount = data.total;
      }

      renderRegistrants(registrationsList, totalCount);
    } catch (err) {
      console.error(err);
    }
  }

  // Menangani klik tombol submit untuk membuat pendaftaran baru (POST) atau memperbarui data (PUT).
  if (submitBtn) {
    submitBtn.addEventListener("click", async function (e) {
      // Mencegah perilaku default submit form (seperti reload halaman otomatis).
      e.preventDefault();

      // Mengambil nilai input dan menghapus spasi di awal/akhir menggunakan .trim().
      let fullname = "";
      if (fullnameInput && fullnameInput.value) {
        fullname = fullnameInput.value.trim();
      }

      let email = "";
      if (emailInput && emailInput.value) {
        email = emailInput.value.trim();
      }

      let phone = "";
      if (phoneInput && phoneInput.value) {
        phone = phoneInput.value.trim();
      }

      let notes = "";
      if (notesInput && notesInput.value) {
        notes = notesInput.value.trim();
      }

      // Validasi field wajib: fullname dan email tidak boleh kosong.
      if (!fullname || !email) {
        alert("Please fill in both Full name and Email.");
        return;
      }

      // Kunci tombol submit saat request ke server sedang berjalan.
      submitBtn.disabled = true;

      try {
        // Jika editingId terisi, berarti sedang memperbarui data (PUT); jika kosong, berarti tambah data baru (POST).
        const isUpdating = Boolean(editingId);
        let url = "/api/registrations";
        let method = "POST";

        if (isUpdating) {
          url = `/api/registrations/${encodeURIComponent(editingId)}`;
          method = "PUT";
        }

        const payload = {
          fullname: fullname,
          email: email,
          phone: phone,
          notes: notes,
        };

        // Mengirim data JSON ke endpoint Flask.
        const res = await fetch(url, {
          method: method,
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });

        const data = await res.json();

        if (!res.ok) {
          let errorMessage = "Failed to save registration.";
          if (data && data.error) {
            errorMessage = data.error;
          }
          alert(errorMessage);
          return;
        }

        // Bersihkan form, perbarui daftar pendaftar, lalu tampilkan notifikasi jika habis mengupdate.
        clearForm();
        await fetchRegistrations();

        if (isUpdating) {
          showUpdateNotice("Registration details updated successfully.");
        }
      } catch (err) {
        console.error(err);
        alert("Network error while saving registration.");
      } finally {
        // Selalu aktifkan kembali tombol submit setelah proses selesai (berhasil maupun gagal).
        submitBtn.disabled = false;
      }
    });
  }

  // Memuat daftar pendaftar saat halaman dibuka, dan mengisi form edit jika ada parameter ?edit=... di URL.
  fetchRegistrations();
  if (editingId) {
    prefillEditForm(editingId);
  }
}

// USER DETAILS PAGE: GET detail + Edit redirect to / + DELETE
function initUserDetailsPage() {
  // Cek apakah elemen utama halaman detail (.detail_card) ada; jika tidak, keluar dari fungsi ini.
  const detailCard = document.querySelector(".detail_card");
  if (!detailCard) {
    return;
  }

  // Ambil ID pengguna dari URL (misalnya /userdetails/1 -> "1"). Jika tidak ada, arahkan ke /error.
  const userId = getUserIdFromPath();
  if (!userId) {
    window.location.href = "/error";
    return;
  }

  // Ambil elemen-elemen yang akan diisi data detail pengguna dan tombol-tombol aksi.
  const titleEl = document.querySelector(".user_title");
  const timeItems = document.querySelectorAll(".user_time li");
  const detailValues = detailCard.querySelectorAll(".detail_value");
  const buttonRow = detailCard.querySelector(".user_button");

  // Kumpulkan semua tombol di dalam baris tombol (.user_button) sebagai cadangan jika class spesifik tidak ditemukan.
  let allButtons = [];
  if (buttonRow) {
    const nodeListButtons = buttonRow.querySelectorAll("button");
    allButtons = Array.from(nodeListButtons);
  }

  // Cari tombol Back: utamakan class .backtolist-btn, lalu fallback ke tombol pertama.
  let backBtn = detailCard.querySelector(".backtolist-btn");
  if (!backBtn && allButtons[0]) {
    backBtn = allButtons[0];
  }

  // Cari tombol Edit: utamakan class .edit-btn, lalu fallback ke tombol kedua.
  let editBtn = detailCard.querySelector(".edit-btn");
  if (!editBtn && allButtons[1]) {
    editBtn = allButtons[1];
  }

  // Cari tombol Delete: utamakan class .delete-btn, lalu cari tombol berteks "delete", lalu fallback ke tombol ketiga.
  let deleteBtn = detailCard.querySelector(".delete-btn");
  if (!deleteBtn) {
    for (const btn of allButtons) {
      const label = btn.textContent.trim().toLowerCase();
      if (label === "delete") {
        deleteBtn = btn;
        break;
      }
    }
  }
  if (!deleteBtn && allButtons[2]) {
    deleteBtn = allButtons[2];
  }

  // Menyimpan objek data pengguna yang sedang ditampilkan di halaman detail.
  let currentUser = null;

  // Menampilkan data currentUser ke judul dan tiap baris .detail_value (gunakan "-" jika nilainya kosong).
  function renderView() {
    if (!currentUser) {
      return;
    }

    if (titleEl) {
      let rawName = "";
      if (currentUser.fullname) {
        rawName = String(currentUser.fullname);
      }
      titleEl.textContent = rawName.toUpperCase();
    }

    if (detailValues[0]) {
      detailValues[0].textContent = currentUser.fullname ? currentUser.fullname : "-";
    }
    if (detailValues[1]) {
      detailValues[1].textContent = currentUser.email ? currentUser.email : "-";
    }
    if (detailValues[2]) {
      detailValues[2].textContent = currentUser.phone ? currentUser.phone : "-";
    }
    if (detailValues[3]) {
      detailValues[3].textContent = currentUser.registeredAt
        ? currentUser.registeredAt
        : "-";
    }
    if (detailValues[4]) {
      detailValues[4].textContent = currentUser.notes ? currentUser.notes : "-";
    }
  }

  // Mengambil detail pendaftar dari backend berdasarkan userId.
  async function loadUserDetail() {
    try {
      const encodedId = encodeURIComponent(userId);
      const res = await fetch(`/api/registrations/${encodedId}`);

      // Jika userId tidak ditemukan di backend (HTTP 404), arahkan ke halaman error.
      if (res.status === 404) {
        window.location.href = "/error";
        return;
      }

      if (!res.ok) {
        throw new Error("Failed to load user detail");
      }

      const data = await res.json();
      currentUser = data.registration;

      // Perbarui informasi total pendaftar pada elemen .user_time kedua jika tersedia dan bertipe number.
      if (timeItems[1] && typeof data.total === "number") {
        timeItems[1].textContent = `${data.total} registered`;
      }

      renderView();
    } catch (err) {
      console.error(err);
    }
  }

  // Klik tombol Back -> kembali ke halaman utama (/).
  if (backBtn) {
    backBtn.addEventListener("click", function (e) {
      e.preventDefault();
      window.location.href = "/";
    });
  }

  // Klik tombol Edit -> arahkan ke halaman utama dengan query ?edit=<id> agar form otomatis terisi data user ini.
  if (editBtn) {
    editBtn.addEventListener("click", function (e) {
      e.preventDefault();
      const encodedId = encodeURIComponent(userId);
      window.location.href = `/?edit=${encodedId}`;
    });
  }

  // Klik tombol Delete -> minta konfirmasi, kirim DELETE ke API, lalu kembali ke halaman utama (/) jika berhasil.
  if (deleteBtn) {
    deleteBtn.addEventListener("click", async function (e) {
      e.preventDefault();
      const confirmed = confirm("Are you sure you want to remove this registration?");
      if (!confirmed) {
        return;
      }

      deleteBtn.disabled = true;

      try {
        const encodedId = encodeURIComponent(userId);
        const res = await fetch(`/api/registrations/${encodedId}`, {
          method: "DELETE",
        });

        if (!res.ok) {
          alert("Failed to delete registration.");
          deleteBtn.disabled = false;
          return;
        }

        window.location.href = "/";
      } catch (err) {
        console.error(err);
        alert("Network error while deleting registration.");
        deleteBtn.disabled = false;
      }
    });
  }

  // Jalankan pemuatan data detail pengguna saat halaman detail diinisialisasi.
  loadUserDetail();
}

// ERROR PAGE: mengikat tombol kembali ke halaman utama (/)
function initErrorPage() {
  // Jika tombol .error-btn tidak ada di halaman ini, langsung keluar.
  const errorBtn = document.querySelector(".error-btn");
  if (!errorBtn) {
    return;
  }

  // Saat tombol diklik, cegah aksi bawaan lalu arahkan pengguna kembali ke /.
  errorBtn.addEventListener("click", function (e) {
    e.preventDefault();
    window.location.href = "/";
  });
}

// Menunggu struktur HTML (DOM) selesai dimuat penuh sebelum menjalankan fungsi inisialisasi tiap halaman.
document.addEventListener("DOMContentLoaded", () => {
  initIndexPage(); // 1. Dipanggil -> jika elemen halaman index tidak ada, langsung return tanpa error.
  initUserDetailsPage(); // 2. Lanjut dijalankan -> jika elemen halaman detail tidak ada, langsung return.
  initErrorPage(); // 3. Baru dijalankan -> jika tombol error tidak ada, langsung return.
});